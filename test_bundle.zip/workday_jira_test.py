import pytest
from unittest.mock import Mock, patch
import requests
from workday_jira_connector import WorkdayToJiraConnector, RateLimitException, ConnectorError

@pytest.fixture
def mock_env(monkeypatch):
    monkeypatch.setenv("WORKDAY_API_KEY", "test_src_key")
    monkeypatch.setenv("JIRA_API_KEY", "test_dst_key")

@pytest.fixture
def connector(mock_env):
    return WorkdayToJiraConnector()

def test_init_missing_keys(monkeypatch):
    monkeypatch.delenv("WORKDAY_API_KEY", raising=False)
    with pytest.raises(ValueError):
        WorkdayToJiraConnector()

@patch('requests.Session.get')
def test_authenticate_success(mock_get, connector):
    mock_resp = Mock()
    mock_resp.status_code = 200
    mock_resp.raise_for_status.return_value = None
    mock_get.return_value = mock_resp
    
    assert connector.authenticate() is True
    assert mock_get.call_count == 2

@patch('requests.Session.get')
def test_fetch_records_success(mock_get, connector):
    mock_resp = Mock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"data": [{"id": "1"}], "next_cursor": "abc"}
    mock_get.return_value = mock_resp
    
    result = connector.fetch_records()
    assert len(result["data"]) == 1
    assert result["next_cursor"] == "abc"

@patch('requests.Session.get')
def test_fetch_records_rate_limit(mock_get, connector):
    mock_resp = Mock()
    mock_resp.status_code = 429
    mock_get.return_value = mock_resp
    
    with pytest.raises(RateLimitException):
        connector.fetch_records.retry.stop = Mock(return_value=True) # Bypass retry for test
        connector.fetch_records()

@patch('requests.Session.post')
def test_create_record_success(mock_post, connector):
    mock_resp = Mock()
    mock_resp.status_code = 201
    mock_resp.json.return_value = {"id": "new_1", "status": "created"}
    mock_post.return_value = mock_resp
    
    result = connector.create_record({"name": "test"})
    assert result["status"] == "created"
    assert mock_post.called
