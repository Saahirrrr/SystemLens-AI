# Workday to Jira Connector

## Overview
This connector is an enterprise-grade integration script designed to extract `Employee Information` from `Workday` and load it into `Jira`. 

It features:
- **Resiliency**: Built-in exponential backoff for rate limits using `tenacity`.
- **Pagination**: Fully supports paginated extraction from source APIs.
- **Connection Pooling**: Uses `requests.Session` with custom HTTPAdapters.
- **Test Coverage**: Includes a standard test suite via `pytest`.

## Installation

1. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Environment Variables
Create a `.env` file or export the following variables:

```bash
export WORKDAY_API_KEY="your_source_api_key"
export JIRA_API_KEY="your_destination_api_key"
```

## Usage

You can use the connector directly in a Python script:

```python
from workday_jira_connector import WorkdayToJiraConnector

connector = WorkdayToJiraConnector()
records_synced = connector.sync_all()
print(f"Successfully synced {records_synced} records.")
```

## Testing

Run the provided test suite using pytest:

```bash
pytest workday_jira_test.py -v
```

## Deployment Notes
- When deploying as a scheduled cron job or serverless function, ensure the timeout exceeds the maximum pagination processing time.
- The `agent.yaml` is provided for orchestration within an Agentic Framework.
