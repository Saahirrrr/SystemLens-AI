"""
Connector for synchronizing Employee Information from Workday to Jira.
"""
import os
import logging
from typing import Dict, Any, List, Optional
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

logger = logging.getLogger(__name__)

class RateLimitException(Exception):
    pass

class ConnectorError(Exception):
    pass

class WorkdayToJiraConnector:
    """Handles authentication, pagination, and CRUD operations for Employee Information."""

    def __init__(self):
        self.src_api_key = os.getenv("WORKDAY_API_KEY")
        self.dst_api_key = os.getenv("JIRA_API_KEY")
        
        if not self.src_api_key or not self.dst_api_key:
            raise ValueError("API keys for both Workday and Jira must be set in the environment.")
            
        self.src_base_url = os.getenv("WORKDAY_BASE_URL", "https://api.workday.com/v1")
        self.dst_base_url = os.getenv("JIRA_BASE_URL", "https://api.jira.com/v1")
        
        self.session = self._setup_session()

    def _setup_session(self) -> requests.Session:
        """Configures a requests session with robust connection pooling and base retries."""
        session = requests.Session()
        retries = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[408, 429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS", "POST", "PUT"]
        )
        adapter = HTTPAdapter(max_retries=retries, pool_connections=10, pool_maxsize=10)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        return session

    def authenticate(self) -> bool:
        """Validates credentials against both systems."""
        try:
            # Authenticate with Source
            src_response = self.session.get(
                f"{self.src_base_url}/auth/verify",
                headers={"Authorization": f"Bearer {self.src_api_key}"}
            )
            src_response.raise_for_status()
            
            # Authenticate with Destination
            dst_response = self.session.get(
                f"{self.dst_base_url}/auth/verify",
                headers={"Authorization": f"Bearer {self.dst_api_key}"}
            )
            dst_response.raise_for_status()
            return True
        except requests.exceptions.RequestException as e:
            logger.error(f"Authentication failed: {e}")
            return False

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((requests.exceptions.ConnectionError, requests.exceptions.Timeout, RateLimitException))
    )
    def fetch_records(self, limit: int = 100, cursor: Optional[str] = None) -> Dict[str, Any]:
        """Fetches Employee Information records from Workday with pagination."""
        url = f"{self.src_base_url}/employee_informations"
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
            
        response = self.session.get(
            url,
            headers={"Authorization": f"Bearer {self.src_api_key}"},
            params=params,
            timeout=10
        )
        
        if response.status_code == 429:
            logger.warning("Rate limit hit on source system.")
            raise RateLimitException("Rate limit exceeded")
            
        response.raise_for_status()
        return response.json()

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=5),
        retry=retry_if_exception_type((requests.exceptions.ConnectionError, requests.exceptions.Timeout))
    )
    def create_record(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Creates a new Employee Information record in Jira."""
        url = f"{self.dst_base_url}/employee_informations"
        response = self.session.post(
            url,
            headers={"Authorization": f"Bearer {self.dst_api_key}", "Content-Type": "application/json"},
            json=data,
            timeout=10
        )
        response.raise_for_status()
        return response.json()
        
    def sync_all(self) -> int:
        """Executes a full synchronization pipeline, handling pagination."""
        logger.info("Starting synchronization pipeline...")
        if not self.authenticate():
            raise ConnectorError("Cannot start sync; authentication failed.")
            
        cursor = None
        records_processed = 0
        has_more = True
        
        while has_more:
            page = self.fetch_records(limit=100, cursor=cursor)
            records = page.get("data", [])
            
            for record in records:
                try:
                    # In a real scenario, transformation logic happens here
                    transformed = self._transform(record)
                    self.create_record(transformed)
                    records_processed += 1
                except Exception as e:
                    logger.error(f"Failed to sync record {record.get('id')}: {e}")
                    
            cursor = page.get("next_cursor")
            has_more = bool(cursor)
            
        logger.info(f"Synchronization complete. Processed {records_processed} records.")
        return records_processed
        
    def _transform(self, source_record: Dict[str, Any]) -> Dict[str, Any]:
        """Transforms source schema to destination schema."""
        # Baseline identity mapping
        return source_record
